package Library_pakage;


import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class TrivelClearTRip
{
	public static void calanderclearTrip(WebDriver driver, String dot,String iconXpath, String calxpath,String calMonthYearXpath,String nextXpath ) throws InterruptedException
	{
		{
			String dateray[]= dot.split("/"); 
			String date=dateray[0];
			String month=dateray[1];
			String year=dateray[2];
			System.out.println("the one is :" +date+","+month+","+year);
			
			driver.findElement(By.xpath(iconXpath)).click(); 
			String calMonthYear=driver.findElement(By.xpath(calMonthYearXpath)).getText();
			System.out.println("the get text is "+calMonthYear);

			while (!(calMonthYear).equalsIgnoreCase(month+" " +year)) 
				{
					driver.findElement(By.xpath(nextXpath)).click(); //next
					calMonthYear=driver.findElement(By.xpath(calMonthYearXpath)).getText();//current value
				}
			Thread.sleep(5000);
			
			WebElement cal=driver.findElement(By.xpath(calxpath));
			
			List<WebElement> rows=cal.findElements(By.tagName("tr"));
			cat:
			for (int i = 1; i < rows.size(); i++) 
				{
				List<WebElement> cols=rows.get(i).findElements(By.tagName("td"));
				for (int j = 0; j < cols.size(); j++) 
				{
					String caldt=cols.get(j).getText(); 
					if (caldt.equals(date)) 		
						{
						cols.get(j).click();
						break cat;
						}
				}
				}
			}
		}

}
