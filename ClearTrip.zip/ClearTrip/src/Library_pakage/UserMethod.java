package Library_pakage;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.concurrent.TimeUnit;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

public class UserMethod 
{
private static final String FileUtils = null;
public static WebDriver driver; 
public static String driverpath; 
static FileInputStream fileip;
static XSSFWorkbook workbook;
static XSSFCell cell2;
public static String excelFile;
static String scrnsht ;
static String URL ;

public static void readFiles(String ExcelLocation ,String screenshotLocation)
{
	//this methoed is to metion all files used in the program
	excelFile = ExcelLocation;
	scrnsht = screenshotLocation;
}

public static  WebDriver driverInstantiate(String browsername, String URL) //change driver location
{  
if(browsername.equalsIgnoreCase("chrome")) 
{ 	
driverpath = "D:\\Auomation\\ClearTrip\\driver\\chromedriver.exe";
System.setProperty("webdriver.chrome.driver", driverpath); 	
ChromeOptions op = new ChromeOptions();
op.addArguments("--disable-notifications");// to disable nnotifications in website
driver = new ChromeDriver();                 
} 
else if(browsername.equalsIgnoreCase("ie")) 
{ 
driverpath = "D:\\Auomation\\ClearTrip\\driver\\chromedriver.exe"; 	
System.setProperty("webdriver.ie.driver", driverpath); 	
driver = new InternetExplorerDriver();                 
}
else if(browsername.equalsIgnoreCase("firefox")) 
{
driverpath = "E:\\#cognizant\\softwares\\new selenium\\geckodriver-v0.26.0-win64\\geckodriver.exe";
System.setProperty("webdriver.gecko.driver", driverpath);
driver = new FirefoxDriver();  
}
driver.get(URL);
driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); 
driver.manage().window().maximize(); 
driver.manage().deleteAllCookies(); 
return driver; 
}
public static String  readexcel(int i, int c) throws FileNotFoundException, IOException
{
fileip = new FileInputStream(new File(excelFile));
workbook = new XSSFWorkbook(fileip);
String Values = (workbook.getSheetAt(0).getRow(i).getCell(c)).getStringCellValue();
return Values;
//Note:- excel reads only string value --change numeric type of cell in excel to TEXT type 
} 
public static void writeexcel(String val1, int i, int j) throws IOException
{
cell2 =workbook.getSheetAt(0).getRow(i).createCell(j);
cell2.setCellValue(val1);
fileip.close();
FileOutputStream fileop =new FileOutputStream(new File(excelFile));
workbook.write(new FileOutputStream(new File(excelFile)));
fileop.close();
}
public static void screenShot() throws WebDriverException, IOException
{
FileUtils.copyFile(((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE), new File(scrnsht+System.currentTimeMillis()+".png"));	
}
}

